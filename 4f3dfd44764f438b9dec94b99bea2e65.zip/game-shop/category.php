<?php require_once __DIR__.'/includes/header.php';
$id = (int)($_GET['id'] ?? 0);
$cat = $pdo->prepare("SELECT * FROM categories WHERE id=?");
$cat->execute([$id]); $cat = $cat->fetch();
$items = [];
if ($cat) {
    $stmt = $pdo->prepare("SELECT * FROM items WHERE category_id=? AND status='active' ORDER BY id DESC");
    $stmt->execute([$id]); $items = $stmt->fetchAll();
}
?>
<div class="container">
  <div class="section">
    <div class="section-title"><div class="bar"></div>
      <h2><?= $cat ? e($cat['icon'].' '.$cat['name']) : 'ไม่พบหมวดหมู่' ?></h2>
    </div>
    <div class="item-grid">
      <?php foreach ($items as $it): $st = stockCount($it['id']); ?>
        <div class="item-card fade-up">
          <div class="item-img"><img src="<?= e($it['image']) ?>" alt="<?= e($it['name']) ?>"></div>
          <div class="item-body">
            <div class="item-name"><?= e($it['name']) ?></div>
            <div style="font-size:.82rem;color:var(--muted);margin-bottom:.4rem"><?= e(mb_substr($it['description']??'',0,60)) ?></div>
            <div class="item-stock <?= $st>0?'in':'out' ?>"><?= $st>0?'✅ คงเหลือ '.$st.' ชิ้น':'❌ หมดชั่วคราว' ?></div>
            <div class="item-bottom">
              <span class="item-price">฿<?= number_format($it['price'],2) ?></span>
              <button class="btn-buy" data-id="<?= $it['id'] ?>" <?= $st<=0||!$me?'disabled':'' ?>>
                <?= $me?($st>0?'ซื้อเลย':'หมด'):'เข้าสู่ระบบ' ?>
              </button>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
      <?php if (empty($items)): ?><p style="color:var(--muted)">ยังไม่มีสินค้าในหมวดนี้</p><?php endif; ?>
    </div>
  </div>
</div>
<?php require_once __DIR__.'/includes/footer.php'; ?>
