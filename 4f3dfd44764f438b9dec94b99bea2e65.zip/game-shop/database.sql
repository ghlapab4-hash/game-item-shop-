-- ============================================
--  Game Item Shop - Database Schema
--  White Theme Full-Stack (PHP + MySQL)
-- ============================================

CREATE DATABASE IF NOT EXISTS `game_shop` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `game_shop`;

-- ------- Users -------
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `avatar` VARCHAR(255) DEFAULT 'assets/images/default-avatar.png',
  `role` ENUM('user','admin') DEFAULT 'user',
  `credit` DECIMAL(10,2) DEFAULT 0.00,
  `total_topup` DECIMAL(10,2) DEFAULT 0.00,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Default Admin (username: admin / password: admin123)
INSERT INTO `users` (`username`,`email`,`password`,`role`,`credit`) VALUES
('admin','admin@shop.com','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','admin',99999.00);

-- ------- Website Settings -------
CREATE TABLE IF NOT EXISTS `settings` (
  `id` INT PRIMARY KEY DEFAULT 1,
  `site_name` VARCHAR(100) DEFAULT 'Game Item Shop',
  `site_title` VARCHAR(100) DEFAULT 'Game Item Shop - Buy Game Items',
  `contact_link` VARCHAR(255) DEFAULT 'https://www.facebook.com/share/1CjKRWwrd5/',
  `line_qr` VARCHAR(255) DEFAULT '',
  `truemoney_phone` VARCHAR(20) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO `settings` (`id`) VALUES (1) ON DUPLICATE KEY UPDATE id=id;

-- ------- Slides -------
CREATE TABLE IF NOT EXISTS `slides` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `image` VARCHAR(255) NOT NULL,
  `link` VARCHAR(255) DEFAULT '#',
  `sort_order` INT DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------- Categories -------
CREATE TABLE IF NOT EXISTS `categories` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `icon` VARCHAR(100) DEFAULT '🎮',
  `show_home` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------- Items (Products) -------
CREATE TABLE IF NOT EXISTS `items` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `category_id` INT NOT NULL,
  `name` VARCHAR(150) NOT NULL,
  `description` TEXT,
  `price` DECIMAL(10,2) NOT NULL,
  `image` VARCHAR(255) DEFAULT 'assets/images/default-item.png',
  `show_home` TINYINT(1) DEFAULT 1,
  `status` ENUM('active','inactive') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------- Stock (Item Codes) -------
CREATE TABLE IF NOT EXISTS `stock` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `item_id` INT NOT NULL,
  `code` VARCHAR(255) NOT NULL,
  `status` ENUM('available','sold') DEFAULT 'available',
  `sold_at` TIMESTAMP NULL,
  `buyer_id` INT NULL,
  FOREIGN KEY (`item_id`) REFERENCES `items`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------- Purchase History -------
CREATE TABLE IF NOT EXISTS `purchases` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `item_id` INT NOT NULL,
  `item_name` VARCHAR(150),
  `price` DECIMAL(10,2),
  `code` VARCHAR(255),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------- Topup History -------
CREATE TABLE IF NOT EXISTS `topups` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `amount` DECIMAL(10,2) NOT NULL,
  `method` VARCHAR(50) DEFAULT 'truemoney',
  `transaction_id` VARCHAR(100),
  `status` ENUM('pending','success','failed') DEFAULT 'pending',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
