<?php require_once __DIR__.'/includes/header.php';
// Slides
$slides = $pdo->query("SELECT * FROM slides ORDER BY sort_order, id")->fetchAll();
// Stats
$total_users = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$total_stock = (int)$pdo->query("SELECT COUNT(*) FROM stock WHERE status='available'")->fetchColumn();
$total_sold  = (int)$pdo->query("SELECT COUNT(*) FROM purchases")->fetchColumn();
// Featured categories & items
$cats = $pdo->query("SELECT * FROM categories WHERE show_home=1 ORDER BY id")->fetchAll();
$items = $pdo->query("SELECT i.*, c.name AS cat_name FROM items i JOIN categories c ON i.category_id=c.id WHERE i.show_home=1 AND i.status='active' ORDER BY i.id DESC LIMIT 8")->fetchAll();
?>
<div class="container">

  <!-- Slider 1300x400 -->
  <div class="slider fade-up">
    <?php if (empty($slides)): ?>
      <div class="slide active" style="background:linear-gradient(135deg,#6366f1,#06b6d4);display:flex;align-items:center;justify-content:center;color:#fff;font-size:2rem;font-weight:700">
        🎮 ยินดีต้อนรับสู่ <?= e($site['site_name']) ?>
      </div>
    <?php else: foreach ($slides as $i=>$s): ?>
      <div class="slide <?= $i===0?'active':'' ?>">
        <a href="<?= e($s['link']) ?>"><img src="<?= e($s['image']) ?>" alt="slide"></a>
      </div>
    <?php endforeach; endif; ?>
    <button class="slider-arrow prev">‹</button>
    <button class="slider-arrow next">›</button>
    <div class="slider-dots">
      <?php for($i=0;$i<max(1,count($slides));$i++): ?>
        <span class="dot <?= $i===0?'active':'' ?>"></span>
      <?php endfor; ?>
    </div>
  </div>

  <!-- Stats 3 boxes -->
  <div class="stats">
    <div class="stat-card fade-up delay-1">
      <div class="stat-icon c1">👥</div>
      <div><div class="stat-num"><?= number_format($total_users) ?></div><div class="stat-label">จำนวนสมาชิก</div></div>
    </div>
    <div class="stat-card fade-up delay-2">
      <div class="stat-icon c2">📦</div>
      <div><div class="stat-num"><?= number_format($total_stock) ?></div><div class="stat-label">สินค้าในสต๊อก</div></div>
    </div>
    <div class="stat-card fade-up delay-3">
      <div class="stat-icon c3">🔥</div>
      <div><div class="stat-num"><?= number_format($total_sold) ?></div><div class="stat-label">สินค้าที่จำหน่ายไปแล้ว</div></div>
    </div>
  </div>

  <!-- Featured Categories -->
  <div class="section">
    <div class="section-title"><div class="bar"></div><h2>หมวดหมู่แนะนำ</h2></div>
    <div class="cat-grid">
      <?php foreach ($cats as $c): ?>
        <a href="category.php?id=<?= $c['id'] ?>" class="cat-card fade-up">
          <div class="cat-icon"><?= e($c['icon']) ?></div>
          <div class="cat-name"><?= e($c['name']) ?></div>
        </a>
      <?php endforeach; ?>
      <?php if (empty($cats)): ?><p style="color:var(--muted)">ยังไม่มีหมวดหมู่แนะนำ</p><?php endif; ?>
    </div>
  </div>

  <!-- Featured Items -->
  <div class="section">
    <div class="section-title"><div class="bar"></div><h2>สินค้าแนะนำ</h2></div>
    <div class="item-grid">
      <?php foreach ($items as $it): $st = stockCount($it['id']); ?>
        <div class="item-card fade-up">
          <div class="item-img"><img src="<?= e($it['image']) ?>" alt="<?= e($it['name']) ?>"></div>
          <div class="item-body">
            <div class="item-name"><?= e($it['name']) ?></div>
            <div class="item-stock <?= $st>0?'in':'out' ?>"><?= $st>0?'✅ คงเหลือ '.$st.' ชิ้น':'❌ หมดชั่วคราว' ?></div>
            <div class="item-bottom">
              <span class="item-price">฿<?= number_format($it['price'],2) ?></span>
              <button class="btn-buy" data-id="<?= $it['id'] ?>" <?= $st<=0||!$me?'disabled':'' ?>>
                <?= $me?($st>0?'ซื้อเลย':'หมด'):'เข้าสู่ระบบ' ?>
              </button>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
      <?php if (empty($items)): ?><p style="color:var(--muted)">ยังไม่มีสินค้าแนะนำ</p><?php endif; ?>
    </div>
  </div>
</div>
<?php require_once __DIR__.'/includes/footer.php'; ?>
