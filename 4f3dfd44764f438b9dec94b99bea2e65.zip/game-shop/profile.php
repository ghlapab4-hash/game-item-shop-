<?php require_once __DIR__.'/includes/header.php'; requireLogin(); $me = currentUser(); ?>
<div class="container">
  <div class="section">
    <div class="section-title"><div class="bar"></div><h2>💳 โปรไฟล์ & เครดิต</h2></div>
    <div class="topup-grid">
      <div class="topup-card fade-up" style="text-align:center">
        <img src="<?= e($me['avatar']) ?>" style="width:120px;height:120px;border-radius:50%;object-fit:cover;border:4px solid var(--primary);margin-bottom:1rem">
        <h3><?= e($me['username']) ?></h3>
        <p style="color:var(--muted)"><?= e($me['email']) ?></p>
        <span class="badge <?= $me['role']==='admin'?'admin':'user' ?>" style="margin:.5rem 0;display:inline-block"><?= strtoupper($me['role']) ?></span>
        <div style="margin-top:1.5rem;padding:1.2rem;background:linear-gradient(135deg,var(--primary),var(--accent));color:#fff;border-radius:16px">
          <div style="font-size:.9rem;opacity:.9">เครดิตคงเหลือ</div>
          <div style="font-size:2.2rem;font-weight:800">฿<?= number_format($me['credit'],2) ?></div>
          <div style="font-size:.85rem;opacity:.9;margin-top:.3rem">ยอดเติมรวม: ฿<?= number_format($me['total_topup'],2) ?></div>
        </div>
        <a href="topup.php" class="btn btn-success" style="margin-top:1rem">➕ เติมเงินเพิ่ม</a>
      </div>
      <div class="topup-card fade-up delay-1">
        <h3 style="margin-bottom:1rem">📜 ประวัติล่าสุด</h3>
        <div class="table-wrap">
          <table>
            <tr><th>สินค้า</th><th>ราคา</th><th>วันที่</th></tr>
            <?php
            $stmt = $pdo->prepare("SELECT * FROM purchases WHERE user_id=? ORDER BY id DESC LIMIT 8");
            $stmt->execute([$me['id']]);
            foreach ($stmt as $p): ?>
            <tr><td><?= e($p['item_name']) ?></td><td>฿<?= number_format($p['price'],2) ?></td>
                <td style="font-size:.8rem"><?= e($p['created_at']) ?></td></tr>
            <?php endforeach; ?>
          </table>
        </div>
        <a href="history.php" style="display:block;text-align:center;margin-top:1rem;color:var(--primary);font-weight:600">ดูประวัติทั้งหมด →</a>
      </div>
    </div>
  </div>
</div>
<?php require_once __DIR__.'/includes/footer.php'; ?>
