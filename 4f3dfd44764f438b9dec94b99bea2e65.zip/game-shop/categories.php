<?php require_once __DIR__.'/includes/header.php';
$cats = $pdo->query("SELECT c.*, (SELECT COUNT(*) FROM items WHERE category_id=c.id AND status='active') AS cnt FROM categories c ORDER BY c.id")->fetchAll();
?>
<div class="container">
  <div class="section">
    <div class="section-title"><div class="bar"></div><h2>หมวดหมู่สินค้าทั้งหมด</h2></div>
    <div class="cat-grid">
      <?php foreach ($cats as $c): ?>
        <a href="category.php?id=<?= $c['id'] ?>" class="cat-card fade-up">
          <div class="cat-icon"><?= e($c['icon']) ?></div>
          <div class="cat-name"><?= e($c['name']) ?></div>
          <div style="font-size:.8rem;color:var(--muted);margin-top:.3rem"><?= $c['cnt'] ?> สินค้า</div>
        </a>
      <?php endforeach; ?>
      <?php if (empty($cats)): ?><p style="color:var(--muted)">ยังไม่มีหมวดหมู่</p><?php endif; ?>
    </div>
  </div>
</div>
<?php require_once __DIR__.'/includes/footer.php'; ?>
