<?php
require_once __DIR__.'/config/functions.php';
$err = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $u = trim($_POST['username'] ?? '');
    $e = trim($_POST['email'] ?? '');
    $p = $_POST['password'] ?? '';
    $p2 = $_POST['password2'] ?? '';
    if ($p !== $p2) $err = 'รหัสผ่านไม่ตรงกัน';
    elseif (strlen($p)<6) $err = 'รหัสผ่านต้องอย่างน้อย 6 ตัวอักษร';
    else {
        $chk = $pdo->prepare("SELECT id FROM users WHERE username=? OR email=?");
        $chk->execute([$u,$e]);
        if ($chk->fetch()) { $err = 'ชื่อผู้ใช้หรืออีเมลนี้มีคนใช้แล้ว'; }
        else {
            $hash = password_hash($p, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (username,email,password) VALUES (?,?,?)");
            $stmt->execute([$u,$e,$hash]);
            header('Location: login.php?registered=1'); exit;
        }
    }
}
?>
<!DOCTYPE html><html lang="th"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>สมัครสมาชิก - <?= e($site['site_name']) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
<link rel="stylesheet" href="assets/css/style.css"></head><body>
<div class="auth-wrap">
  <div class="auth-card fade-up">
    <h2>📝 สมัครสมาชิก</h2>
    <?php if ($err): ?><div class="alert error"><?= e($err) ?></div><?php endif; ?>
    <form method="POST">
      <div class="form-group"><label>ชื่อผู้ใช้</label>
        <input type="text" name="username" class="form-control" required minlength="3"></div>
      <div class="form-group"><label>อีเมล</label>
        <input type="email" name="email" class="form-control" required></div>
      <div class="form-group"><label>รหัสผ่าน</label>
        <input type="password" name="password" class="form-control" required minlength="6"></div>
      <div class="form-group"><label>ยืนยันรหัสผ่าน</label>
        <input type="password" name="password2" class="form-control" required></div>
      <button type="submit" class="btn-primary">สมัครสมาชิก</button>
    </form>
    <div class="auth-link">มีบัญชีแล้ว? <a href="login.php">เข้าสู่ระบบ</a></div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php if ($err): ?><script>Swal.fire('ผิดพลาด!','<?= e($err) ?>','error');</script><?php endif; ?>
</body></html>
