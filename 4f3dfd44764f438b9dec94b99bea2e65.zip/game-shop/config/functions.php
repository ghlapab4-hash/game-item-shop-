<?php
session_start();
require_once __DIR__.'/db.php';

function isLoggedIn() { return isset($_SESSION['user_id']); }
function isAdmin() { return isset($_SESSION['user_role']) && $_SESSION['user_role']==='admin'; }
function currentUser() {
    global $pdo;
    if (!isLoggedIn()) return null;
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id=?");
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch();
}
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: login.php?redirect='.urlencode($_SERVER['REQUEST_URI']));
        exit;
    }
}
function requireAdmin() {
    requireLogin();
    if (!isAdmin()) {
        header('Location: ../index.php');
        exit;
    }
}
function e($s) { return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }
function redirect($url) { header("Location: $url"); exit; }
function stockCount($item_id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM stock WHERE item_id=? AND status='available'");
    $stmt->execute([$item_id]);
    return (int)$stmt->fetchColumn();
}
