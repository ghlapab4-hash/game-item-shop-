<?php
// Database Configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'game_shop');
define('DB_USER', 'root');
define('DB_PASS', '');

try {
    $pdo = new PDO(
        "mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4",
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
         PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
    );
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Load site settings
$stmt = $pdo->query("SELECT * FROM settings WHERE id=1");
$site = $stmt->fetch();
if (!$site) {
    $site = ['site_name'=>'Game Item Shop','site_title'=>'Game Item Shop',
             'contact_link'=>'https://www.facebook.com/share/1CjKRWwrd5/',
             'line_qr'=>'','truemoney_phone'=>''];
}
