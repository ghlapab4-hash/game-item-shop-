<?php
require_once __DIR__.'/config/functions.php';
header('Content-Type: application/json');

if (!isLoggedIn()) { echo json_encode(['success'=>false,'msg'=>'กรุณาเข้าสู่ระบบก่อนซื้อ']); exit; }
if ($_SERVER['REQUEST_METHOD']!=='POST') { echo json_encode(['success'=>false,'msg'=>'Method not allowed']); exit; }

$item_id = (int)($_POST['item_id'] ?? 0);
$user = currentUser();

// Get item
$stmt = $pdo->prepare("SELECT * FROM items WHERE id=? AND status='active'");
$stmt->execute([$item_id]); $item = $stmt->fetch();
if (!$item) { echo json_encode(['success'=>false,'msg'=>'ไม่พบสินค้า']); exit; }

// Check credit
if ($user['credit'] < $item['price']) {
    echo json_encode(['success'=>false,'msg'=>'เครดิตไม่เพียงพอ กรุณาเติมเงิน']); exit;
}

// Get one available code (lock row)
$pdo->beginTransaction();
$stmt = $pdo->prepare("SELECT * FROM stock WHERE item_id=? AND status='available' LIMIT 1 FOR UPDATE");
$stmt->execute([$item_id]); $code = $stmt->fetch();
if (!$code) {
    $pdo->rollBack();
    echo json_encode(['success'=>false,'msg'=>'สินค้าหมดชั่วคราว']); exit;
}

// Deduct credit
$pdo->prepare("UPDATE users SET credit=credit-? WHERE id=?")->execute([$item['price'], $user['id']]);
// Mark code sold
$pdo->prepare("UPDATE stock SET status='sold', sold_at=NOW(), buyer_id=? WHERE id=?")
    ->execute([$user['id'], $code['id']]);
// Record purchase
$pdo->prepare("INSERT INTO purchases (user_id,item_id,item_name,price,code) VALUES (?,?,?,?,?)")
    ->execute([$user['id'], $item['id'], $item['name'], $item['price'], $code['code']]);
$pdo->commit();

echo json_encode(['success'=>true, 'code'=>$code['code'], 'item'=>$item['name']]);
