<?php
require_once __DIR__.'/config/functions.php';
$err = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $u = trim($_POST['username'] ?? '');
    $p = $_POST['password'] ?? '';
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username=? OR email=?");
    $stmt->execute([$u,$u]);
    $user = $stmt->fetch();
    if ($user && password_verify($p, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['username'] = $user['username'];
        $redir = $_GET['redirect'] ?? 'index.php';
        header("Location: $redir"); exit;
    } else {
        $err = 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง';
    }
}
?>
<!DOCTYPE html><html lang="th"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>เข้าสู่ระบบ - <?= e($site['site_name']) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
<link rel="stylesheet" href="assets/css/style.css"></head><body>
<div class="auth-wrap">
  <div class="auth-card fade-up">
    <h2>🔐 เข้าสู่ระบบ</h2>
    <?php if ($err): ?><div class="alert error"><?= e($err) ?></div><?php endif; ?>
    <form method="POST">
      <div class="form-group"><label>ชื่อผู้ใช้ / อีเมล</label>
        <input type="text" name="username" class="form-control" required placeholder="กรอกชื่อผู้ใช้"></div>
      <div class="form-group"><label>รหัสผ่าน</label>
        <input type="password" name="password" class="form-control" required placeholder="กรอกรหัสผ่าน"></div>
      <button type="submit" class="btn-primary">เข้าสู่ระบบ</button>
    </form>
    <div class="auth-link">ยังไม่มีบัญชี? <a href="register.php">สมัครสมาชิก</a> | <a href="index.php">กลับหน้าแรก</a></div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
<?php if ($err): ?>
Swal.fire('ผิดพลาด!','<?= e($err) ?>','error');
<?php endif; ?>
</script>
</body></html>
