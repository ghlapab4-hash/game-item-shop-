// ===== Main JS - Game Item Shop =====
document.addEventListener('DOMContentLoaded', () => {

  // ---- Profile Dropdown ----
  const avatar = document.getElementById('avatarBtn');
  const dropdown = document.getElementById('profileDropdown');
  if (avatar && dropdown) {
    avatar.addEventListener('click', (e) => {
      e.stopPropagation();
      dropdown.classList.toggle('show');
    });
    document.addEventListener('click', () => dropdown.classList.remove('show'));
  }

  // ---- Slider ----
  const slides = document.querySelectorAll('.slide');
  const dots = document.querySelectorAll('.dot');
  let cur = 0;
  if (slides.length > 0) {
    const go = (i) => {
      slides.forEach(s => s.classList.remove('active'));
      dots.forEach(d => d.classList.remove('active'));
      cur = (i + slides.length) % slides.length;
      slides[cur].classList.add('active');
      if (dots[cur]) dots[cur].classList.add('active');
    };
    dots.forEach((d, i) => d.addEventListener('click', () => go(i)));
    document.querySelector('.slider-arrow.prev')?.addEventListener('click', () => go(cur - 1));
    document.querySelector('.slider-arrow.next')?.addEventListener('click', () => go(cur + 1));
    setInterval(() => go(cur + 1), 5000);
  }

  // ---- Amount selector (topup) ----
  document.querySelectorAll('.amount-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.amount-btn').forEach(b => b.classList.remove('selected'));
      btn.classList.add('selected');
      const amt = document.getElementById('amountInput');
      if (amt) amt.value = btn.dataset.amount;
    });
  });

  // ---- Buy Item (AJAX) ----
  document.querySelectorAll('.btn-buy').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.id;
      Swal.fire({
        title: 'ยืนยันการซื้อ?',
        text: 'จะหักเครดิตจากบัญชีคุณทันที',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'ซื้อเลย!',
        cancelButtonText: 'ยกเลิก',
        confirmButtonColor: '#6366f1'
      }).then(r => {
        if (!r.isConfirmed) return;
        fetch('buy.php', {
          method: 'POST',
          headers: {'Content-Type':'application/x-www-form-urlencoded'},
          body: 'item_id=' + id
        }).then(res => res.json()).then(data => {
          if (data.success) {
            Swal.fire({
              title: 'ซื้อสำเร็จ! 🎉',
              html: 'รหัสไอเทมของคุณ: <br><b style="font-size:1.3rem;color:#6366f1">' + data.code + '</b>',
              icon: 'success',
              confirmButtonText: 'รับรหัสแล้ว',
              confirmButtonColor: '#10b981'
            }).then(() => location.reload());
          } else {
            Swal.fire('ผิดพลาด!', data.msg, 'error');
          }
        });
      });
    });
  });

  // ---- Confirm links (delete etc.) ----
  document.querySelectorAll('[data-confirm]').forEach(el => {
    el.addEventListener('click', (e) => {
      e.preventDefault();
      Swal.fire({
        title: 'ยืนยันการลบ?',
        text: 'ไม่สามารถกู้คืนได้',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#ef4444',
        confirmButtonText: 'ลบเลย'
      }).then(r => { if (r.isConfirmed) window.location = el.href; });
    });
  });

  // ---- Toggle switches ----
  document.querySelectorAll('.toggle-switch').forEach(t => {
    t.addEventListener('change', () => {
      fetch(t.dataset.url + (t.checked ? 1 : 0)).then(() => {
        Swal.fire({ toast:true, position:'top-end', icon:'success',
          title:'อัปเดตแล้ว', showConfirmButton:false, timer:1500 });
      });
    });
  });
});

// Helper: copy to clipboard
function copyCode(text) {
  navigator.clipboard.writeText(text);
  Swal.fire({ toast:true, position:'top-end', icon:'success',
    title:'คัดลอกแล้ว!', showConfirmButton:false, timer:1200 });
}
