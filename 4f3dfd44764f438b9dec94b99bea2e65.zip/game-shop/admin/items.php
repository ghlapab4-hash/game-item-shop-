<?php require_once __DIR__.'/header.php';
$uploadDir = __DIR__.'/../uploads/items/';
if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
$msg='';
if (isset($_POST['add']) || isset($_POST['edit'])) {
    $cat=(int)$_POST['category_id']; $name=trim($_POST['name']); $desc=trim($_POST['description']);
    $price=(float)$_POST['price']; $show=(int)($_POST['show_home']??0); $status=$_POST['status'];
    $img = $_POST['old_image'] ?? '';
    if (!empty($_FILES['image']['tmp_name'])) {
        $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $fn = 'item_'.time().'.'.$ext;
        move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir.$fn);
        $img = 'uploads/items/'.$fn;
    }
    if (!$img) $img = 'assets/images/default-item.png';
    if (isset($_POST['add'])) {
        $pdo->prepare("INSERT INTO items (category_id,name,description,price,image,show_home,status) VALUES (?,?,?,?,?,?,?)")
            ->execute([$cat,$name,$desc,$price,$img,$show,$status]);
    } else {
        $id=(int)$_POST['id'];
        $pdo->prepare("UPDATE items SET category_id=?,name=?,description=?,price=?,image=?,show_home=?,status=? WHERE id=?")
            ->execute([$cat,$name,$desc,$price,$img,$show,$status,$id]);
    }
    $msg='ok';
}
if (isset($_GET['del'])) { $pdo->prepare("DELETE FROM items WHERE id=?")->execute([(int)$_GET['del']]); header('Location: items.php'); exit; }
if (isset($_GET['toggle'])) {
    $id=(int)$_GET['toggle']; $val=(int)$_GET['val'];
    $pdo->prepare("UPDATE items SET show_home=? WHERE id=?")->execute([$val,$id]); exit;
}
$edit_id=(int)($_GET['edit']??0); $edit_item=null;
if ($edit_id){$s=$pdo->prepare("SELECT * FROM items WHERE id=?");$s->execute([$edit_id]);$edit_item=$s->fetch();}
$cats = $pdo->query("SELECT * FROM categories ORDER BY id")->fetchAll();
$items = $pdo->query("SELECT i.*, c.name AS cat_name FROM items i JOIN categories c ON i.category_id=c.id ORDER BY i.id DESC")->fetchAll();
?>
<h1 style="margin-bottom:1.5rem">🎮 จัดการสินค้าและสต๊อก</h1>
<div class="admin-card">
  <h3><?= $edit_item?'✏️ แก้ไขสินค้า':'➕ เพิ่มสินค้าใหม่' ?></h3>
  <form method="POST" enctype="multipart/form-data">
    <?php if ($edit_item): ?><input type="hidden" name="id" value="<?= $edit_item['id'] ?>"><input type="hidden" name="old_image" value="<?= e($edit_item['image']) ?>"><?php endif; ?>
    <div class="form-row">
      <div class="form-group"><label>หมวดหมู่</label>
        <select name="category_id" class="form-control" required>
          <?php foreach ($cats as $c): ?>
            <option value="<?= $c['id'] ?>" <?= $edit_item&&$edit_item['category_id']==$c['id']?'selected':'' ?>><?= e($c['icon'].' '.$c['name']) ?></option>
          <?php endforeach; ?>
        </select></div>
      <div class="form-group"><label>ชื่อสินค้า</label>
        <input type="text" name="name" class="form-control" value="<?= $edit_item?e($edit_item['name']):'' ?>" required></div>
    </div>
    <div class="form-group"><label>รายละเอียดสินค้า</label>
      <textarea name="description" class="form-control" rows="2"><?= $edit_item?e($edit_item['description']):'' ?></textarea></div>
    <div class="form-row">
      <div class="form-group"><label>ราคา (บาท)</label>
        <input type="number" step="0.01" name="price" class="form-control" value="<?= $edit_item?$edit_item['price']:'' ?>" required></div>
      <div class="form-group"><label>สถานะ</label>
        <select name="status" class="form-control">
          <option value="active" <?= $edit_item&&$edit_item['status']==='active'?'selected':'' ?>>เปิดขาย</option>
          <option value="inactive" <?= $edit_item&&$edit_item['status']==='inactive'?'selected':'' ?>>ปิดขาย</option>
        </select></div>
    </div>
    <div class="form-group"><label>รูปสินค้า</label>
      <input type="file" name="image" class="form-control" accept="image/*"></div>
    <div class="form-group" style="display:flex;align-items:center;gap:.5rem">
      <input type="checkbox" name="show_home" value="1" <?= $edit_item&&$edit_item['show_home']?'checked':'' ?> style="width:20px;height:20px;accent-color:#6366f1">
      <label style="margin:0">แสดงที่หน้าแรก (สินค้าแนะนำ)</label></div>
    <button type="submit" name="<?= $edit_item?'edit':'add' ?>" class="btn btn-success">💾 <?= $edit_item?'บันทึกการแก้ไข':'เพิ่มสินค้า' ?></button>
    <?php if ($edit_item): ?><a href="items.php" class="btn btn-warning">ยกเลิก</a><?php endif; ?>
  </form>
</div>
<div class="admin-card">
  <h3>📋 สินค้าทั้งหมด (<?= count($items) ?>)</h3>
  <div class="table-wrap">
    <table><tr><th>รูป</th><th>ชื่อสินค้า</th><th>หมวด</th><th>ราคา</th><th>สต็อก</th><th>หน้าแรก</th><th>จัดการ</th></tr>
    <?php foreach ($items as $it): $st=stockCount($it['id']); ?>
    <tr>
      <td><img src="../<?= e($it['image']) ?>" style="width:50px;height:50px;object-fit:cover;border-radius:8px"></td>
      <td><?= e($it['name']) ?></td><td><?= e($it['cat_name']) ?></td>
      <td style="color:var(--primary);font-weight:700">฿<?= number_format($it['price'],2) ?></td>
      <td><span class="badge <?= $st>0?'success':'danger' ?>"><?= $st ?> ชิ้น</span></td>
      <td><label style="display:inline-flex;align-items:center;gap:.4rem;cursor:pointer">
        <input type="checkbox" class="toggle-switch" data-url="?toggle=<?= $it['id'] ?>&val=" <?= $it['show_home']?'checked':'' ?> style="width:18px;height:18px;accent-color:#6366f1"></label></td>
      <td>
        <a href="stock.php?item=<?= $it['id'] ?>" class="btn btn-info">📦 สต็อก</a>
        <a href="?edit=<?= $it['id'] ?>" class="btn btn-warning">✏️</a>
        <a href="?del=<?= $it['id'] ?>" class="btn btn-danger" data-confirm>🗑️</a>
      </td>
    </tr>
    <?php endforeach; ?>
    </table>
  </div>
</div>
<?php if ($msg): ?><script>Swal.fire('สำเร็จ!','บันทึกสินค้าเรียบร้อย','success')</script><?php endif; ?>
<?php require_once __DIR__.'/footer.php'; ?>
