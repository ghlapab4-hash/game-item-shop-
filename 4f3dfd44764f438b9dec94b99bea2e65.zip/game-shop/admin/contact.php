<?php require_once __DIR__.'/header.php';
$uploadDir = __DIR__.'/../uploads/qr/';
$msg='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $link = trim($_POST['contact_link']);
    $qr = $_POST['old_qr'] ?? '';
    if (!empty($_FILES['line_qr']['tmp_name'])) {
        $ext = pathinfo($_FILES['line_qr']['name'], PATHINFO_EXTENSION);
        $fn = 'line_qr_'.time().'.'.$ext;
        move_uploaded_file($_FILES['line_qr']['tmp_name'], $uploadDir.$fn);
        $qr = 'uploads/qr/'.$fn;
    }
    $pdo->prepare("UPDATE settings SET contact_link=?, line_qr=? WHERE id=1")->execute([$link,$qr]);
    $site = $pdo->query("SELECT * FROM settings WHERE id=1")->fetch();
    $msg='ok';
}
?>
<h1 style="margin-bottom:1.5rem">💬 ตั้งค่าระบบติดต่อ</h1>
<div class="admin-card">
  <h3>🔗 ลิงก์ปุ่ม "ติดต่อสอบถาม"</h3>
  <form method="POST" enctype="multipart/form-data">
    <input type="hidden" name="old_qr" value="<?= e($site['line_qr']) ?>">
    <div class="form-group"><label>ลิงก์ติดต่อ (Facebook / Line / อื่นๆ)</label>
      <input type="url" name="contact_link" class="form-control" value="<?= e($site['contact_link']) ?>" placeholder="https://..."></div>
    <div class="form-group"><label>อัปโหลดรูป QR Code Line (ถ้ามี)</label>
      <input type="file" name="line_qr" class="form-control" accept="image/*">
      <?php if (!empty($site['line_qr'])): ?>
        <div style="margin-top:.8rem"><img src="../<?= e($site['line_qr']) ?>" style="width:140px;border-radius:12px;border:2px solid var(--border)"></div>
      <?php endif; ?></div>
    <button type="submit" class="btn btn-success">💾 บันทึกการตั้งค่า</button>
  </form>
  <div class="alert success" style="margin-top:1.5rem">
    <b>📌 ปุ่มติดต่อ (ลอยมุมขวาล่าง):</b> จะเปิดลิงก์ที่ตั้งค่าไว้ในแท็บใหม่<br>
    <b>📌 ค่าเริ่มต้น:</b> <code>https://www.facebook.com/share/1CjKRWwrd5/</code> (ตามที่คุณให้มา)
  </div>
</div>
<?php if ($msg): ?><script>Swal.fire('บันทึกแล้ว!','อัปเดตลิงก์ติดต่อเรียบร้อย','success')</script><?php endif; ?>
<?php require_once __DIR__.'/footer.php'; ?>
