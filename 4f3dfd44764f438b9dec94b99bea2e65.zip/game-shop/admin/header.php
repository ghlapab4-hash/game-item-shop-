<?php
require_once __DIR__.'/../config/functions.php';
requireAdmin();
$me = currentUser();
$page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html><html lang="th"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin - <?= e($site['site_name']) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
<link rel="stylesheet" href="../assets/css/style.css"></head><body>
<div class="admin-layout">
  <aside class="sidebar">
    <div class="sidebar-logo">⚙️ Admin Panel</div>
    <a href="index.php" class="<?= $page=='index.php'?'active':'' ?>">📊 แดชบอร์ด</a>
    <a href="settings.php" class="<?= $page=='settings.php'?'active':'' ?>">🌐 ตั้งค่าเว็บไซต์</a>
    <a href="slides.php" class="<?= $page=='slides.php'?'active':'' ?>">🖼️ จัดการรูปสไลด์</a>
    <a href="categories.php" class="<?= $page=='categories.php'?'active':'' ?>">📁 จัดการหมวดหมู่</a>
    <a href="items.php" class="<?= $page=='items.php'?'active':'' ?>">🎮 จัดการสินค้า</a>
    <a href="stock.php" class="<?= $page=='stock.php'?'active':'' ?>">📦 จัดการสต็อก (โค้ด)</a>
    <a href="topup_config.php" class="<?= $page=='topup_config.php'?'active':'' ?>">💰 ตั้งค่าเติมเงิน</a>
    <a href="contact.php" class="<?= $page=='contact.php'?'active':'' ?>">💬 ตั้งค่าติดต่อ</a>
    <a href="users.php" class="<?= $page=='users.php'?'active':'' ?>">👥 จัดการสมาชิก</a>
    <a href="../index.php" style="margin-top:1rem;color:var(--muted)">← กลับหน้าเว็บ</a>
    <a href="../logout.php" style="color:#ef4444">🚪 ออกจากระบบ</a>
  </aside>
  <main class="admin-main">
