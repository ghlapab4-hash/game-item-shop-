<?php require_once __DIR__.'/header.php';
$msg='';
// Actions
if (isset($_POST['reset_pw'])) {
    $id=(int)$_POST['user_id']; $hash=password_hash($_POST['new_pw'], PASSWORD_DEFAULT);
    $pdo->prepare("UPDATE users SET password=? WHERE id=?")->execute([$hash,$id]); $msg='รีเซ็ตรหัสผ่านแล้ว';
}
if (isset($_POST['change_role'])) {
    $id=(int)$_POST['user_id']; $role=$_POST['role'];
    $pdo->prepare("UPDATE users SET role=? WHERE id=?")->execute([$role,$id]); $msg='เปลี่ยนยศแล้ว';
}
if (isset($_POST['adjust_credit'])) {
    $id=(int)$_POST['user_id']; $amt=(float)$_POST['amount'];
    $pdo->prepare("UPDATE users SET credit=credit+? WHERE id=?")->execute([$amt,$id]);
    if ($amt>0) $pdo->prepare("UPDATE users SET total_topup=total_topup+? WHERE id=?")->execute([$amt,$id]);
    $msg=($amt>=0?'เพิ่ม':'ลด').'เครดิต '.abs($amt).' บาทแล้ว';
}
if (isset($_GET['del'])) { $pdo->prepare("DELETE FROM users WHERE id=?")->execute([(int)$_GET['del']]); header('Location: users.php'); exit; }
$users = $pdo->query("SELECT * FROM users ORDER BY id DESC")->fetchAll();
?>
<h1 style="margin-bottom:1.5rem">👥 จัดการสมาชิก (<?= count($users) ?> คน)</h1>
<div class="admin-card">
  <div class="table-wrap">
    <table><tr><th>#</th><th>ผู้ใช้</th><th>อีเมล</th><th>ยศ</th><th>เครดิต</th><th>เติมรวม</th><th>จัดการ</th></tr>
    <?php foreach ($users as $i=>$u): ?>
    <tr>
      <td><?= $i+1 ?></td>
      <td><img src="../<?= e($u['avatar']) ?>" style="width:32px;height:32px;border-radius:50%;vertical-align:middle;margin-right:.5rem;object-fit:cover"><?= e($u['username']) ?></td>
      <td style="font-size:.85rem"><?= e($u['email']) ?></td>
      <td><span class="badge <?= $u['role']==='admin'?'admin':'user' ?>"><?= strtoupper($u['role']) ?></span></td>
      <td style="color:var(--primary);font-weight:700">฿<?= number_format($u['credit'],2) ?></td>
      <td>฿<?= number_format($u['total_topup'],2) ?></td>
      <td>
        <button class="btn btn-warning" style="padding:.3rem .7rem;font-size:.8rem" onclick="pwModal(<?= $u['id'] ?>,'<?= e($u['username']) ?>')">🔑 รหัส</button>
        <button class="btn btn-info" style="padding:.3rem .7rem;font-size:.8rem" onclick="creditModal(<?= $u['id'] ?>,'<?= e($u['username']) ?>')">💰 เครดิต</button>
        <button class="btn btn-success" style="padding:.3rem .7rem;font-size:.8rem" onclick="roleModal(<?= $u['id'] ?>,'<?= e($u['username']) ?>','<?= $u['role'] ?>')">🎖️ ยศ</button>
        <?php if ($u['id']!==$_SESSION['user_id']): ?>
        <a href="?del=<?= $u['id'] ?>" class="btn btn-danger" data-confirm style="padding:.3rem .7rem;font-size:.8rem">🗑️</a>
        <?php endif; ?>
      </td>
    </tr>
    <?php endforeach; ?>
    </table>
  </div>
</div>
<script>
function pwModal(id,name){
  Swal.fire({title:'รีเซ็ตรหัสผ่าน - '+name,input:'text',inputLabel:'รหัสผ่านใหม่',inputPlaceholder:'รหัสผ่านอย่างน้อย 6 ตัว',
    showCancelButton:true,confirmButtonText:'บันทึก',confirmButtonColor:'#f59e0b'}).then(r=>{
    if(r.isConfirmed && r.value){
      const f=document.createElement('form');f.method='POST';
      f.innerHTML='<input name="reset_pw" value="1"><input name="user_id" value="'+id+'"><input name="new_pw" value="'+r.value+'">';
      document.body.appendChild(f);f.submit();
    }
  });
}
function creditModal(id,name){
  Swal.fire({title:'ปรับเครดิต - '+name,input:'number',inputLabel:'จำนวน (บวก=เพิ่ม, ลบ=ลด)',inputPlaceholder:'เช่น 100 หรือ -50',
    showCancelButton:true,confirmButtonText:'ยืนยัน',confirmButtonColor:'#06b6d4'}).then(r=>{
    if(r.isConfirmed && r.value!==''){
      const f=document.createElement('form');f.method='POST';
      f.innerHTML='<input name="adjust_credit" value="1"><input name="user_id" value="'+id+'"><input name="amount" value="'+r.value+'">';
      document.body.appendChild(f);f.submit();
    }
  });
}
function roleModal(id,name,cur){
  Swal.fire({title:'เปลี่ยนยศ - '+name,input:'select',inputOptions:{user:'User (สมาชิกทั่วไป)',admin:'Admin (ผู้ดูแล)'},
    inputValue:cur,showCancelButton:true,confirmButtonText:'บันทึก',confirmButtonColor:'#10b981'}).then(r=>{
    if(r.isConfirmed && r.value){
      const f=document.createElement('form');f.method='POST';
      f.innerHTML='<input name="change_role" value="1"><input name="user_id" value="'+id+'"><input name="role" value="'+r.value+'">';
      document.body.appendChild(f);f.submit();
    }
  });
}
<?php if ($msg): ?>
Swal.fire('สำเร็จ!','<?= $msg ?>','success');
<?php endif; ?>
</script>
<?php require_once __DIR__.'/footer.php'; ?>
