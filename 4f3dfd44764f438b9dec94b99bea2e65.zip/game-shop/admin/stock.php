<?php require_once __DIR__.'/header.php';
$msg='';
$item_id = (int)($_GET['item'] ?? 0);
// Add codes (bulk)
if (isset($_POST['add_codes'])) {
    $iid=(int)$_POST['item_id'];
    $codes = preg_split('/\r\n|\r|\n/', trim($_POST['codes']));
    $cnt=0;
    foreach ($codes as $c) {
        $c=trim($c); if ($c) { $pdo->prepare("INSERT INTO stock (item_id,code) VALUES (?,?)")->execute([$iid,$c]); $cnt++; }
    }
    $msg="เพิ่มโค้ด $cnt รายการ";
}
if (isset($_GET['del'])) { $pdo->prepare("DELETE FROM stock WHERE id=?")->execute([(int)$_GET['del']]); header('Location: stock.php'.($item_id?'?item='.$item_id:'')); exit; }
$items = $pdo->query("SELECT * FROM items ORDER BY id")->fetchAll();
$where = $item_id ? "WHERE item_id=$item_id" : '';
$stocks = $pdo->query("SELECT s.*, i.name AS item_name FROM stock s JOIN items i ON s.item_id=i.id $where ORDER BY s.id DESC LIMIT 200")->fetchAll();
$sel_item = null;
if ($item_id){$s=$pdo->prepare("SELECT * FROM items WHERE id=?");$s->execute([$item_id]);$sel_item=$s->fetch();}
?>
<h1 style="margin-bottom:1.5rem">📦 จัดการสต็อก (โค้ดไอเทม)</h1>
<div class="admin-card">
  <h3>➕ เพิ่มโค้ดสินค้า <?= $sel_item?' - '.e($sel_item['name']):'' ?></h3>
  <form method="POST">
    <div class="form-group"><label>เลือกสินค้า</label>
      <select name="item_id" class="form-control" required>
        <?php foreach ($items as $it): ?>
          <option value="<?= $it['id'] ?>" <?= $item_id==$it['id']?'selected':'' ?>><?= e($it['name']) ?> (฿<?= number_format($it['price'],2) ?>)</option>
        <?php endforeach; ?>
      </select></div>
    <div class="form-group"><label>วางโค้ด (1 บรรทัดต่อ 1 โค้ด - วางหลายบรรทัดได้เลย)</label>
      <textarea name="codes" class="form-control" rows="6" placeholder="CODE-XXXX-0001&#10;CODE-XXXX-0002&#10;CODE-XXXX-0003" required></textarea></div>
    <button type="submit" name="add_codes" class="btn btn-success">➕ เพิ่มโค้ดทั้งหมด</button>
  </form>
</div>
<div class="admin-card">
  <h3>📋 โค้ดในระบบ (แสดงล่าสุด 200 รายการ) - <a href="stock.php" class="btn btn-info" style="padding:.3rem .8rem;font-size:.8rem">ทั้งหมด</a></h3>
  <div class="table-wrap">
    <table><tr><th>#</th><th>สินค้า</th><th>โค้ด</th><th>สถานะ</th><th>ผู้ซื้อ</th><th>จัดการ</th></tr>
    <?php foreach ($stocks as $i=>$s): ?>
    <tr>
      <td><?= $i+1 ?></td><td><?= e($s['item_name']) ?></td>
      <td><code style="background:#f1f5f9;padding:.2rem .5rem;border-radius:6px;font-size:.8rem"><?= e($s['code']) ?></code></td>
      <td><span class="badge <?= $s['status']==='available'?'success':'danger' ?>"><?= $s['status']==='available'?'พร้อมขาย':'ขายแล้ว' ?></span></td>
      <td style="font-size:.8rem"><?= $s['sold_at']?e($s['sold_at']):'-' ?></td>
      <td><?php if ($s['status']==='available'): ?><a href="?del=<?= $s['id'] ?><?= $item_id?'&item='.$item_id:'' ?>" class="btn btn-danger" data-confirm style="padding:.3rem .7rem;font-size:.8rem">🗑️</a><?php endif; ?></td>
    </tr>
    <?php endforeach; ?>
    </table>
  </div>
</div>
<?php if ($msg): ?><script>Swal.fire('สำเร็จ!','<?= $msg ?>','success')</script><?php endif; ?>
<?php require_once __DIR__.'/footer.php'; ?>
