<?php require_once __DIR__.'/header.php';
$msg = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $name = trim($_POST['site_name']);
    $title = trim($_POST['site_title']);
    $pdo->prepare("UPDATE settings SET site_name=?, site_title=? WHERE id=1")->execute([$name,$title]);
    $msg = 'success';
    $site = $pdo->query("SELECT * FROM settings WHERE id=1")->fetch();
}
?>
<h1 style="margin-bottom:1.5rem">🌐 ตั้งค่าเว็บไซต์ทั่วไป</h1>
<div class="admin-card">
  <form method="POST">
    <div class="form-group"><label>ชื่อเว็บไซต์ (Website Name)</label>
      <input type="text" name="site_name" class="form-control" value="<?= e($site['site_name']) ?>" required></div>
    <div class="form-group"><label>ชื่อแท็บเบราว์เซอร์ (Title)</label>
      <input type="text" name="site_title" class="form-control" value="<?= e($site['site_title']) ?>" required></div>
    <button type="submit" class="btn btn-success">💾 บันทึกการตั้งค่า</button>
  </form>
</div>
<?php if ($msg): ?><script>Swal.fire('บันทึกแล้ว!','อัปเดตการตั้งค่าสำเร็จ','success')</script><?php endif; ?>
<?php require_once __DIR__.'/footer.php'; ?>
