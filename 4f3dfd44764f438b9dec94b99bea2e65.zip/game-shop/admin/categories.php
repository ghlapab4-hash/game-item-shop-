<?php require_once __DIR__.'/header.php';
$msg='';
if (isset($_POST['add'])) {
    $name=trim($_POST['name']); $icon=trim($_POST['icon']);
    $pdo->prepare("INSERT INTO categories (name,icon) VALUES (?,?)")->execute([$name,$icon]); $msg='add';
}
if (isset($_POST['edit'])) {
    $id=(int)$_POST['id']; $name=trim($_POST['name']); $icon=trim($_POST['icon']);
    $pdo->prepare("UPDATE categories SET name=?, icon=? WHERE id=?")->execute([$name,$icon,$id]); $msg='edit';
}
if (isset($_GET['del'])) {
    $pdo->prepare("DELETE FROM categories WHERE id=?")->execute([(int)$_GET['del']]); header('Location: categories.php'); exit;
}
if (isset($_GET['toggle'])) {
    $id=(int)$_GET['toggle']; $val=(int)$_GET['val'];
    $pdo->prepare("UPDATE categories SET show_home=? WHERE id=?")->execute([$val,$id]); exit;
}
$edit_id = (int)($_GET['edit'] ?? 0);
$edit_cat = null;
if ($edit_id) { $s=$pdo->prepare("SELECT * FROM categories WHERE id=?"); $s->execute([$edit_id]); $edit_cat=$s->fetch(); }
$cats = $pdo->query("SELECT * FROM categories ORDER BY id")->fetchAll();
?>
<h1 style="margin-bottom:1.5rem">📁 จัดการหมวดหมู่สินค้า</h1>
<div class="admin-card">
  <h3><?= $edit_cat?'✏️ แก้ไขหมวดหมู่':'➕ เพิ่มหมวดหมู่ใหม่' ?></h3>
  <form method="POST">
    <?php if ($edit_cat): ?><input type="hidden" name="id" value="<?= $edit_cat['id'] ?>"><?php endif; ?>
    <div class="form-row">
      <div class="form-group"><label>ชื่อหมวดหมู่</label>
        <input type="text" name="name" class="form-control" value="<?= $edit_cat?e($edit_cat['name']):'' ?>" required></div>
      <div class="form-group"><label>ไอคอน (Emoji)</label>
        <input type="text" name="icon" class="form-control" value="<?= $edit_cat?e($edit_cat['icon']):'🎮' ?>" maxlength="10"></div>
    </div>
    <button type="submit" name="<?= $edit_cat?'edit':'add' ?>" class="btn btn-success">💾 <?= $edit_cat?'บันทึกการแก้ไข':'เพิ่มหมวดหมู่' ?></button>
    <?php if ($edit_cat): ?><a href="categories.php" class="btn btn-warning">ยกเลิก</a><?php endif; ?>
  </form>
</div>
<div class="admin-card">
  <h3>📋 หมวดหมู่ทั้งหมด</h3>
  <div class="table-wrap">
    <table><tr><th>#</th><th>ไอคอน</th><th>ชื่อ</th><th>แสดงที่หน้าแรก</th><th>จัดการ</th></tr>
    <?php foreach ($cats as $i=>$c): ?>
    <tr>
      <td><?= $i+1 ?></td><td style="font-size:1.5rem"><?= e($c['icon']) ?></td><td><?= e($c['name']) ?></td>
      <td><label style="display:inline-flex;align-items:center;gap:.5rem;cursor:pointer">
        <input type="checkbox" class="toggle-switch" data-url="?toggle=<?= $c['id'] ?>&val=" <?= $c['show_home']?'checked':'' ?> style="width:20px;height:20px;accent-color:#6366f1">
        <span class="badge <?= $c['show_home']?'success':'danger' ?>"><?= $c['show_home']?'แสดง':'ซ่อน' ?></span></label></td>
      <td>
        <a href="?edit=<?= $c['id'] ?>" class="btn btn-warning">✏️ แก้ไข</a>
        <a href="?del=<?= $c['id'] ?>" class="btn btn-danger" data-confirm>🗑️ ลบ</a>
      </td>
    </tr>
    <?php endforeach; ?>
    </table>
  </div>
</div>
<?php if ($msg): ?><script>Swal.fire('สำเร็จ!','บันทึกข้อมูลเรียบร้อย','success')</script><?php endif; ?>
<?php require_once __DIR__.'/footer.php'; ?>
