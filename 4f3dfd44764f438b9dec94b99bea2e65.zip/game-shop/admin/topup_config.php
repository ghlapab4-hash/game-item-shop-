<?php require_once __DIR__.'/header.php';
$msg='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $phone = trim($_POST['truemoney_phone']);
    $pdo->prepare("UPDATE settings SET truemoney_phone=? WHERE id=1")->execute([$phone]);
    $site = $pdo->query("SELECT * FROM settings WHERE id=1")->fetch();
    $msg='ok';
}
?>
<h1 style="margin-bottom:1.5rem">💰 ตั้งค่าระบบเติมเงิน</h1>
<div class="admin-card">
  <h3>🧧 เบอร์โทรศัพท์รับเงินจากซองอั่งเปา TrueMoney Wallet</h3>
  <form method="POST">
    <div class="form-group"><label>เบอร์โทรศัพท์ (10 หลัก)</label>
      <input type="text" name="truemoney_phone" class="form-control" value="<?= e($site['truemoney_phone']) ?>" placeholder="0812345678" maxlength="10"></div>
    <button type="submit" class="btn btn-success">💾 บันทึกเบอร์</button>
  </form>
  <div class="alert success" style="margin-top:1.5rem">
    <b>📌 หมายเหตุ:</b> ไฟล์ <code>Voucher.php</code> อยู่ที่ root ของโปรเจกต์ เมื่อคุณได้โค้ดระบบซองอั่งเปาจริงมาแล้ว
    ให้แทนที่เนื้อหาในไฟล์นั้นเลย ระบบจะทำงานอัตโนมัติกับหน้าเติมเงินทันที (ไม่ต้องแก้ไฟล์อื่น)
  </div>
</div>
<?php if ($msg): ?><script>Swal.fire('บันทึกแล้ว!','อัปเดตเบอร์เรียบร้อย','success')</script><?php endif; ?>
<?php require_once __DIR__.'/footer.php'; ?>
