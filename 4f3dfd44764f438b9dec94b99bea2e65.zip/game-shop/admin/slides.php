<?php require_once __DIR__.'/header.php';
$uploadDir = __DIR__.'/../uploads/slides/';
$msg='';
// Add slide
if (isset($_POST['add'])) {
    $link = trim($_POST['link']);
    $sort = (int)$_POST['sort_order'];
    $img = '';
    if (!empty($_FILES['image']['tmp_name'])) {
        $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $fn = 'slide_'.time().'.'.$ext;
        move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir.$fn);
        $img = 'uploads/slides/'.$fn;
    }
    if ($img) { $pdo->prepare("INSERT INTO slides (image,link,sort_order) VALUES (?,?,?)")->execute([$img,$link,$sort]); $msg='add'; }
}
// Delete
if (isset($_GET['del'])) {
    $id=(int)$_GET['del'];
    $s=$pdo->prepare("SELECT image FROM slides WHERE id=?"); $s->execute([$id]); $row=$s->fetch();
    if ($row && file_exists(__DIR__.'/../'.$row['image'])) @unlink(__DIR__.'/../'.$row['image']);
    $pdo->prepare("DELETE FROM slides WHERE id=?")->execute([$id]); $msg='del'; header('Location: slides.php'); exit;
}
$slides = $pdo->query("SELECT * FROM slides ORDER BY sort_order, id")->fetchAll();
?>
<h1 style="margin-bottom:1.5rem">🖼️ จัดการรูปสไลด์ (1300x400 px)</h1>
<div class="admin-card">
  <h3>➕ เพิ่มรูปสไลด์ใหม่</h3>
  <form method="POST" enctype="multipart/form-data">
    <div class="form-row">
      <div class="form-group"><label>รูปภาพ (แนะนำ 1300x400)</label>
        <input type="file" name="image" class="form-control" accept="image/*" required></div>
      <div class="form-group"><label>ลิงก์ (คลิกแล้วไปไหน)</label>
        <input type="text" name="link" class="form-control" value="#" placeholder="https://..."></div>
    </div>
    <div class="form-group"><label>ลำดับการแสดง (เลขน้อยก่อน)</label>
      <input type="number" name="sort_order" class="form-control" value="0" style="max-width:150px"></div>
    <button type="submit" name="add" class="btn btn-success">➕ เพิ่มสไลด์</button>
  </form>
</div>
<div class="admin-card">
  <h3>📋 รูปสไลด์ทั้งหมด (<?= count($slides) ?>)</h3>
  <div class="item-grid">
    <?php foreach ($slides as $s): ?>
    <div class="item-card">
      <div class="item-img" style="height:140px"><img src="../<?= e($s['image']) ?>" alt=""></div>
      <div class="item-body">
        <div style="font-size:.85rem;color:var(--muted)">ลำดับ: <?= $s['sort_order'] ?></div>
        <a href="?del=<?= $s['id'] ?>" class="btn btn-danger" data-confirm style="margin-top:.5rem">🗑️ ลบ</a>
      </div>
    </div>
    <?php endforeach; ?>
    <?php if (empty($slides)): ?><p style="color:var(--muted)">ยังไม่มีสไลด์</p><?php endif; ?>
  </div>
</div>
<?php if ($msg==='add'): ?><script>Swal.fire('เพิ่มแล้ว!','สไลด์ถูกเพิ่มเรียบร้อย','success')</script><?php endif; ?>
<?php require_once __DIR__.'/footer.php'; ?>
