<?php require_once __DIR__.'/header.php';
$t_users = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$t_items = (int)$pdo->query("SELECT COUNT(*) FROM items")->fetchColumn();
$t_stock = (int)$pdo->query("SELECT COUNT(*) FROM stock WHERE status='available'")->fetchColumn();
$t_sales = (float)$pdo->query("SELECT COALESCE(SUM(price),0) FROM purchases")->fetchColumn();
$recent = $pdo->query("SELECT p.*, u.username FROM purchases p JOIN users u ON p.user_id=u.id ORDER BY p.id DESC LIMIT 8")->fetchAll();
?>
<h1 style="margin-bottom:1.5rem">📊 แดชบอร์ด</h1>
<div class="stats">
  <div class="stat-card"><div class="stat-icon c1">👥</div><div><div class="stat-num"><?= $t_users ?></div><div class="stat-label">สมาชิกทั้งหมด</div></div></div>
  <div class="stat-card"><div class="stat-icon c2">🎮</div><div><div class="stat-num"><?= $t_items ?></div><div class="stat-label">สินค้าทั้งหมด</div></div></div>
  <div class="stat-card"><div class="stat-icon c3">📦</div><div><div class="stat-num"><?= $t_stock ?></div><div class="stat-label">สต็อกคงเหลือ</div></div></div>
</div>
<div class="admin-card">
  <h3>💰 ยอดขายรวม: ฿<?= number_format($t_sales,2) ?></h3>
</div>
<div class="admin-card">
  <h3>🕒 การซื้อล่าสุด</h3>
  <div class="table-wrap">
    <table><tr><th>ผู้ซื้อ</th><th>สินค้า</th><th>ราคา</th><th>วันที่</th></tr>
    <?php foreach ($recent as $r): ?>
      <tr><td><?= e($r['username']) ?></td><td><?= e($r['item_name']) ?></td>
      <td>฿<?= number_format($r['price'],2) ?></td><td style="font-size:.8rem"><?= e($r['created_at']) ?></td></tr>
    <?php endforeach; ?>
    </table>
  </div>
</div>
<?php require_once __DIR__.'/footer.php'; ?>
