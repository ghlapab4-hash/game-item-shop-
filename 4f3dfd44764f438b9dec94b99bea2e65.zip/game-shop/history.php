<?php require_once __DIR__.'/includes/header.php'; requireLogin(); $me = currentUser();
$stmt = $pdo->prepare("SELECT * FROM purchases WHERE user_id=? ORDER BY id DESC");
$stmt->execute([$me['id']]); $rows = $stmt->fetchAll();
?>
<div class="container">
  <div class="section">
    <div class="section-title"><div class="bar"></div><h2>📜 ประวัติการซื้อทั้งหมด</h2></div>
    <div class="table-wrap">
      <table>
        <tr><th>#</th><th>สินค้า</th><th>รหัสไอเทม</th><th>ราคา</th><th>วันที่</th><th></th></tr>
        <?php foreach ($rows as $i=>$p): ?>
        <tr>
          <td><?= $i+1 ?></td>
          <td><?= e($p['item_name']) ?></td>
          <td><code style="background:#f1f5f9;padding:.2rem .5rem;border-radius:6px"><?= e($p['code']) ?></code></td>
          <td>฿<?= number_format($p['price'],2) ?></td>
          <td style="font-size:.8rem"><?= e($p['created_at']) ?></td>
          <td><button class="btn btn-info" onclick="copyCode('<?= e($p['code']) ?>')">📋 คัดลอก</button></td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($rows)): ?><tr><td colspan="6" style="text-align:center;color:var(--muted);padding:2rem">ยังไม่มีประวัติการซื้อ</td></tr><?php endif; ?>
      </table>
    </div>
  </div>
</div>
<?php require_once __DIR__.'/includes/footer.php'; ?>
