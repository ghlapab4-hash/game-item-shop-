<button class="contact-fab" onclick="window.open('<?= e($site['contact_link']) ?>','_blank')" title="ติดต่อสอบถาม">💬</button>
<footer>
  <div class="container">
    <p style="font-weight:600;margin-bottom:.3rem">© <?= date('Y') ?> <?= e($site['site_name']) ?> - เว็บขายไอเทมเกม คุณภาพมาตรฐาน</p>
    <p style="font-size:.85rem">ระบบปลอดภัย 100% | จัดส่งอัตโนมัติทันทีหลังชำระเงิน</p>
  </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="assets/js/main.js"></script>
</body>
</html>
