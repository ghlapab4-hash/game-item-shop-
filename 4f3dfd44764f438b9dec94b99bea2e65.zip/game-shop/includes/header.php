<?php require_once __DIR__.'/../config/functions.php'; $me = currentUser(); ?>
<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($site['site_title']) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<nav class="navbar">
  <div class="nav-container">
    <a href="index.php" class="logo">🎮 <?= e($site['site_name']) ?></a>
    <div class="nav-links">
      <a href="index.php">หน้าแรก</a>
      <a href="categories.php">หมวดหมู่</a>
      <a href="topup.php">เติมเงิน</a>
      <?php if ($me): ?>
        <div class="profile-wrap">
          <img src="<?= e($me['avatar']) ?>" class="avatar" id="avatarBtn" alt="profile">
          <div class="dropdown" id="profileDropdown">
            <div class="dropdown-head">
              <div style="font-size:.85rem;opacity:.9">สวัสดี, <?= e($me['username']) ?></div>
              <div class="credit">💰 <?= number_format($me['credit'],2) ?> บาท</div>
            </div>
            <a href="profile.php" class="dropdown-item">💳 เครดิตคงเหลือ / โปรไฟล์</a>
            <a href="history.php" class="dropdown-item">📜 ประวัติการซื้อ</a>
            <?php if ($me['role']==='admin'): ?>
              <a href="admin/index.php" class="dropdown-item admin-only">⚙️ ระบบหลังบ้าน</a>
            <?php endif; ?>
            <a href="logout.php" class="dropdown-item" style="color:#ef4444">🚪 ออกจากระบบ</a>
          </div>
        </div>
      <?php else: ?>
        <a href="login.php" class="btn-login">เข้าสู่ระบบ</a>
      <?php endif; ?>
    </div>
  </div>
</nav>
