<?php
// ============================================================
//  Voucher.php - ตัวอย่างโครงสร้างรับโค้ดซองอั่งเปา TrueMoney
//  (ไฟล์จริงที่คุณแนบมาให้ภายหลัง จะแทนที่ส่วนนี้ได้เลย)
//  ระบบจะเรียกไฟล์นี้จากหน้า topup.php เมื่อผู้ใช้กรอกลิงก์ซอง
// ============================================================
require_once __DIR__.'/config/functions.php';
header('Content-Type: application/json');

/*
  วิธีใช้งานจริง:
  1. คุณจะได้ไฟล์ Voucher.php จากระบบซองอั่งเปา (มีฟังก์ชันเช็ค API)
  2. ไฟล์นี้จะรับ $_POST['voucher_url'] และเรียก API เช็คยอด
  3. เมื่อเช็คสำเร็จ ให้ UPDATE credit ของผู้ใช้ + บันทึก topups
  4. คืนค่า JSON {success:true, amount:xxx} หรือ {success:false, msg:'...'}
*/

if (!isLoggedIn()) { echo json_encode(['success'=>false,'msg'=>'กรุณาเข้าสู่ระบบ']); exit; }

$voucher_url = trim($_POST['voucher_url'] ?? '');
$amount = (float)($_POST['amount'] ?? 0);

if (empty($voucher_url)) {
    echo json_encode(['success'=>false,'msg'=>'กรุณาวางลิงก์ซองอั่งเปา']);
    exit;
}

// --- ส่วนนี้จะถูกแทนที่ด้วยโค้ดจริงจากไฟล์ Voucher.php ที่คุณแนบมา ---
// ตัวอย่างโครงสร้างเมื่อมีโค้ดจริง:
/*
$voucher = new TrueMoneyVoucher();   // class จากไฟล์จริง
$result = $voucher->redeem($voucher_url, $site['truemoney_phone']);
if ($result['status']==='success') {
    $amount = $result['amount'];
    $pdo->prepare("UPDATE users SET credit=credit+?, total_topup=total_topup+? WHERE id=?")
        ->execute([$amount, $amount, $_SESSION['user_id']]);
    $pdo->prepare("INSERT INTO topups (user_id,amount,transaction_id,status) VALUES (?,?,?,'success')")
        ->execute([$_SESSION['user_id'], $amount, $result['transaction_id']]);
    echo json_encode(['success'=>true,'amount'=>$amount]);
} else {
    echo json_encode(['success'=>false,'msg'=>$result['message']]);
}
*/

// --- ตอบกลับตัวอย่าง (ก่อนมีไฟล์จริง) ---
echo json_encode([
    'success' => false,
    'msg' => 'ระบบซองอั่งเปากำลังติดตั้งอยู่ กรุณาแนบไฟล์ Voucher.php จริงเพื่อเปิดใช้งาน'
]);
