<?php require_once __DIR__.'/includes/header.php'; requireLogin(); ?>
<div class="container">
  <div class="section">
    <div class="section-title"><div class="bar"></div><h2>💰 เติมเงินเข้าบัญชี</h2></div>
    <div class="topup-grid">

      <!-- QR Code -->
      <div class="topup-card fade-up">
        <h3 style="margin-bottom:1rem">📱 เติมผ่าน QR Code (PromptPay)</h3>
        <div class="qr-box">
          <?php if (!empty($site['line_qr'])): ?>
            <img src="<?= e($site['line_qr']) ?>" alt="QR Code">
          <?php else: ?>
            <div style="padding:3rem;color:var(--muted)">Admin ยังไม่ได้ตั้งค่า QR Code</div>
          <?php endif; ?>
        </div>
        <p style="text-align:center;color:var(--muted);font-size:.9rem">สแกน QR เพื่อโอนเงิน จากนั้นแนบสลิปแจ้งผ่านปุ่มติดต่อ 💬</p>
      </div>

      <!-- TrueMoney Voucher -->
      <div class="topup-card fade-up delay-1">
        <h3 style="margin-bottom:1rem">🧧 เติมผ่านซองอั่งเปา TrueMoney</h3>
        <div class="amount-grid">
          <button class="amount-btn" data-amount="50">50 บาท</button>
          <button class="amount-btn" data-amount="100">100 บาท</button>
          <button class="amount-btn" data-amount="300">300 บาท</button>
          <button class="amount-btn" data-amount="500">500 บาท</button>
          <button class="amount-btn" data-amount="1000">1000 บาท</button>
          <button class="amount-btn" data-amount="5000">5000 บาท</button>
        </div>
        <form id="voucherForm">
          <div class="form-group">
            <label>วางลิงก์ซองอั่งเปา (Voucher Link)</label>
            <input type="url" name="voucher_url" class="form-control" required
                   placeholder="https://gift.truemoney.com/campaign/?v=xxxxxx">
          </div>
          <input type="hidden" name="amount" id="amountInput" value="100">
          <button type="submit" class="btn-primary">🎁 ติดตั้งซองอั่งเปา</button>
        </form>
        <p style="margin-top:1rem;font-size:.82rem;color:var(--muted)">
          * เบอร์รับเงิน: <b><?= e($site['truemoney_phone']?:'ยังไม่ตั้งค่า') ?></b><br>
          * ระบบจะตรวจสอบและเติมเครดิตอัตโนมัติทันที
        </p>
      </div>
    </div>
  </div>
</div>
<script>
document.getElementById('voucherForm').addEventListener('submit', function(e){
  e.preventDefault();
  const fd = new FormData(this);
  Swal.fire({title:'กำลังตรวจสอบซอง...',text:'กรุณารอสักครู่',allowOutsideClick:false,
    didOpen:()=>Swal.showLoading()});
  fetch('Voucher.php',{method:'POST',body:fd})
    .then(r=>r.json()).then(d=>{
      if(d.success){
        Swal.fire('เติมเงินสำเร็จ!','ได้รับ '+d.amount+' บาท','success').then(()=>location.reload());
      } else {
        Swal.fire('ผิดพลาด!', d.msg, 'error');
      }
    });
});
</script>
<?php require_once __DIR__.'/includes/footer.php'; ?>
